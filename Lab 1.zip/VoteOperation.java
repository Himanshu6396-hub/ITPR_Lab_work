import java.util.*; // importing utility classes like Scanner for input

// custom exception class for handling voting eligibility
class NotEligibleException extends Exception {
    public NotEligibleException(String msg) {
        super(msg);
    }
}

public class VotingOperation {

    // method to check if person is eligible for voting
    public static void checkEligibility(int age) throws NotEligibleException {
        if (age < 18) {
            // throwing custom exception if age is less than 18
            throw new NotEligibleException("You are not eligible to vote (must be 18 or above).");
        } else {
            System.out.println("You are eligible to vote!");
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in); // create Scanner object for user input

        try {
            System.out.print("Enter your age: ");
            int age = sc.nextInt(); // reading age from user

            // calling method to check voting eligibility
            checkEligibility(age);

        } catch (NotEligibleException e) {
            // handles the custom exception
            System.out.println("Exception: " + e.getMessage());
        } catch (Exception e) {
            // handles invalid input like text instead of number
            System.out.println("Invalid input! Please enter a valid number.");
        } finally {
            sc.close(); // closing scanner to avoid resource leak
        }
    }
}
