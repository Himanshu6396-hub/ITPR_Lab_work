import java.util.Scanner;

// Custom Exception class for invalid rectangle dimensions
class InvalidValueException extends Exception {
    public InvalidValueException(String message) {
        super(message);
    }
}

// Rectangle class
class Rectangle {
    private double length;
    private double breadth;

    // Constructor to take input
    public Rectangle() throws InvalidValueException { // declaring an exception using throws keyword 
        Scanner sc = new Scanner(System.in); // Creating object of Scanner 3

        System.out.print("Enter length of rectangle: ");
        length = sc.nextDouble();

        System.out.print("Enter breadth of rectangle: ");
        breadth = sc.nextDouble();

        if (length <= 0 || breadth <= 0) {
            throw new InvalidValueException("Length and breadth must be positive values.");
        }
    }

    // Method to calculate area
    public double calculateArea() {
        return length * breadth;
    }

    // Method to calculate perimeter
    public double calculatePerimeter() {
        return 2 * (length + breadth);
    }

    // Method to display area and perimeter
    public void display() {
        System.out.println("\n--- Rectangle Details ---");
        System.out.println("Length: " + length);
        System.out.println("Breadth: " + breadth);
        System.out.println("Area: " + calculateArea());
        System.out.println("Perimeter: " + calculatePerimeter());
    }
}

// Main class
public class RectangleCalculation {
    public static void main(String[] args) {
        try {
            // Creating Rectangle object (input taken inside constructor)
            Rectangle rect = new Rectangle();

            // Displaying rectangle details
            rect.display();
        } 
        catch (InvalidValueException e) {
            System.out.println("Error: " + e.getMessage());
        } 
        catch (Exception e) {
            System.out.println("Invalid input! Please enter numeric values only.");
        }
    }
}